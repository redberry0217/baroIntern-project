const MyPage = () => {
  return <div>MyPage</div>;
};

export default MyPage;
