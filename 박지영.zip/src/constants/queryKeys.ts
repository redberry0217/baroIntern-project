// 쿼리 키 관리
export const TEST_KEY = {
  jsonPlaceholder: ["jsonPlaceholder"],
};
