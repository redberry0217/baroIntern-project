const Header = () => {
  return (
    <div className="border-b border-[#eeccff] bg-black flex flex-col gap-[20px]">
      <p>ㅇㅇㅇ</p>
      <p>ㅅㅅㅅ</p>
    </div>
  );
};

export default Header;
